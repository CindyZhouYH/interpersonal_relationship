package com.books.dao;

/*
public class BookMapper {
    // 增加一本书

    int addBook(Books books){

    }

    // 删除
    int deleteBookById(Books books){

    }

    // 更新
    int updateBook(Books books){

    }
    // 查询
    int queryBookById(Books books){

    }
    // 查询所有书
    ArrayList<Books> queryAllBook(){

    }
}*/
