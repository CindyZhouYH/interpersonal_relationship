package com.relation.dao;

public class addSchoolHelper {
    private String schoolName1;
    private String level1;
    private String year1;
    private String schoolName2;
    private String level2;
    private String year2;
    private String schoolName3;
    private String level3;
    private String year3;
    private String schoolName4;
    private String level4;
    private String year4;
    private String schoolName5;
    private String level5;
    private String year5;

    public addSchoolHelper() {
    }

    public addSchoolHelper(String schoolName1, String level1, String year1, String schoolName2, String level2, String year2, String schoolName3, String level3, String year3, String schoolName4, String level4, String year4, String schoolName5, String level5, String year5) {
        this.schoolName1 = schoolName1;
        this.level1 = level1;
        this.year1 = year1;
        this.schoolName2 = schoolName2;
        this.level2 = level2;
        this.year2 = year2;
        this.schoolName3 = schoolName3;
        this.level3 = level3;
        this.year3 = year3;
        this.schoolName4 = schoolName4;
        this.level4 = level4;
        this.year4 = year4;
        this.schoolName5 = schoolName5;
        this.level5 = level5;
        this.year5 = year5;
    }

    public addSchoolHelper(String schoolName1, String level1, String year1, String schoolName2, String level2, String year2, String schoolName3, String level3, String year3, String schoolName4, String level4, String year4) {
        this.schoolName1 = schoolName1;
        this.level1 = level1;
        this.year1 = year1;
        this.schoolName2 = schoolName2;
        this.level2 = level2;
        this.year2 = year2;
        this.schoolName3 = schoolName3;
        this.level3 = level3;
        this.year3 = year3;
        this.schoolName4 = schoolName4;
        this.level4 = level4;
        this.year4 = year4;
    }

    public addSchoolHelper(String schoolName1, String level1, String year1, String schoolName2, String level2, String year2, String schoolName3, String level3, String year3) {
        this.schoolName1 = schoolName1;
        this.level1 = level1;
        this.year1 = year1;
        this.schoolName2 = schoolName2;
        this.level2 = level2;
        this.year2 = year2;
        this.schoolName3 = schoolName3;
        this.level3 = level3;
        this.year3 = year3;
    }

    public addSchoolHelper(String schoolName1, String level1, String year1, String schoolName2, String level2, String year2) {
        this.schoolName1 = schoolName1;
        this.level1 = level1;
        this.year1 = year1;
        this.schoolName2 = schoolName2;
        this.level2 = level2;
        this.year2 = year2;
    }

    public addSchoolHelper(String schoolName1, String level1, String year1) {
        this.schoolName1 = schoolName1;
        this.level1 = level1;
        this.year1 = year1;
    }

    public String getSchoolName1() {
        return schoolName1;
    }

    public void setSchoolName1(String schoolName1) {
        this.schoolName1 = schoolName1;
    }

    public String getSchoolName2() {
        return schoolName2;
    }

    public void setSchoolName2(String schoolName2) {
        this.schoolName2 = schoolName2;
    }

    public String getSchoolName3() {
        return schoolName3;
    }

    public void setSchoolName3(String schoolName3) {
        this.schoolName3 = schoolName3;
    }

    public String getSchoolName4() {
        return schoolName4;
    }

    public void setSchoolName4(String schoolName4) {
        this.schoolName4 = schoolName4;
    }

    public String getSchoolName5() {
        return schoolName5;
    }

    public void setSchoolName5(String schoolName5) {
        this.schoolName5 = schoolName5;
    }

    public String getLevel1() {
        return level1;
    }

    public void setLevel1(String level1) {
        this.level1 = level1;
    }

    public String getYear1() {
        return year1;
    }

    public void setYear1(String year1) {
        this.year1 = year1;
    }

    public String getLevel2() {
        return level2;
    }

    public void setLevel2(String level2) {
        this.level2 = level2;
    }

    public String getYear2() {
        return year2;
    }

    public void setYear2(String year2) {
        this.year2 = year2;
    }

    public String getLevel3() {
        return level3;
    }

    public void setLevel3(String level3) {
        this.level3 = level3;
    }

    public String getYear3() {
        return year3;
    }

    public void setYear3(String year3) {
        this.year3 = year3;
    }

    public String getLevel4() {
        return level4;
    }

    public void setLevel4(String level4) {
        this.level4 = level4;
    }

    public String getYear4() {
        return year4;
    }

    public void setYear4(String year4) {
        this.year4 = year4;
    }

    public String getLevel5() {
        return level5;
    }

    public void setLevel5(String level5) {
        this.level5 = level5;
    }

    public String getYear5() {
        return year5;
    }

    public void setYear5(String year5) {
        this.year5 = year5;
    }
}
